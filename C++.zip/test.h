// This program adds two numbers and prints their sum.
#include <iostream>
 
int main()
{
  int a;
  int b;
  int sum;
 
  sum = a + b;
 
  std::cout << "The sum of " << a << " and " << b << " is " << sum << "\n";
 
  return 0;
}