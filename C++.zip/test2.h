// This program adds two numbers and prints their soustraction.
#include <iostream>

using namespace std;
int main()
{
  int n=9;
  int i=1;
  
  while (i<=n)
 {
	cout << n <<" modulo " << i << " = " (n%i) << "\n";
 }
 
  return 0;
}