#include <iostream>
#include <new>
#include <math.h>
#include <cmath>
using namespace std;

class body{
	public:
	double norm_mass=0;

	double init_distance=0; //from the origin
	double init_speed=0; //relative to the assumed inertial frame of the computer's memory.

	double init_position_vector[3]; //will be normalized
	double init_speed_vector[3]; //will be normalized


	double position[3];
	double moment[3];
	double force[3];
	double dr_ab[3];
	double dr_ac[3];

	//double *p_position = &position[0];
	//double *p_moment = &moment[0];
	//double *p_force = &force[0];

	//double k_energy=0;
	//double pot_energy=0;
	//double total_energy=0;

	body(double, double, double, double, double, double, double, double, double);
	//double mass_reader(void);
	//void set_number(void);
	void vector_normalization(double *p);
	//void resulting_force();
	//void potential energy();
	//void kinetic energy();


};

/*

The body class' constructor will take the following arguments:
1) The mass of the body
2) The average distance of the body from the sun. It will be taken as the initial distance from the origin of the assumed inertial frame of the computer's memory.
3) The componants of a vector hwo points the right direction of the body's position. This vector will be normalize and then multiplied by the average distance from the sun to constitute the initial position vector.
4) The average speed of the body that we'll use as the initial speed condition.
5) The components of a second vector that we'll use as an initial unit velocity vector. This vector will be normalize and then multiplied by the average speed.

*/
body::body(double input_mass, double input_av_dist, double x, double y, double z, double input_av_speed, double velocity_x, double velocity_y, double velocity_z){
		norm_mass=input_mass;
		init_distance = input_av_dist;
		init_position_vector[0]=x;
		init_position_vector[1]=y;
		init_position_vector[2]=z;
		init_speed=input_av_speed;
		init_speed_vector[0]=velocity_x;
		init_speed_vector[1]=velocity_y;
		init_speed_vector[2]=velocity_z;
}

//Do a class finction that normalizes vectors

void body::vector_normalization(double *vec){
	double norm=0;
	for(int i=0; i<3; i++){
		norm = norm + vec[i]*vec[i];
	}
	if(norm==0)
	{
		cout << "La norme du vecteur est nulle." << endl;
	}
	else
	{
		for(int i=0; i<3; i++){
		vec[i]=vec[i]/norm;
		}
	}
}

int main ()
{
	double const G = 6.67408e-11;
	double const AU= 149597870700; // Astronomical unit in km.
	double const n_sec_jrs= 24*60*60; // Number of second in a day.
	double const convertor = n_sec_jrs/AU; // le nombre par lequel on multiplie les km/s pour passer en UA/j.
	double const masses[3]={1.989e30, 1.898e27, 5.683e26}; // The mass of each body. In the following order: Sun, Jupiter, Saturn
	double const mass_dione=1.095452e21;
	double const norm_masses[3]={1.989e30/1.095452e21, 1.898e27/1.095452e21, 5.683e26/1.095452e21};
	// La constante gravitationnelle doit être modifié de manière à ce que les masse soit comptée en (masse solaire * 10^9) (pour avoir des moments de l'ordre de l'unité)
	double const convertor_G = G * pow((AU/mass_dione),2);
    double const period = 5000; // Temps en année.
	double const dt = 1/(365*period); // Le pas de temps, c'est à dire la fraction que représente un jour par rapport à 5000 ans.
	int const N_body=3; // The number of body in the problem



	// The average distance is taken to be the body's semi-major axis around the sun in AU.
	double const av_distance_sun = 0; //by definition
	double const av_distance_jupiter = 5.2;
	double const av_distance_saturn = 9.58;

    // The average speeds are values in km/s multiplied/converted in AU/day. 1km/s = 24*60*60/149597870700 ~ 5.775e-7 AU/jrs
	double const av_speed_sun=0;//by definition
	double const av_speed_jupiter=13.07*convertor;
	double const av_speed_saturn=9.69*convertor;

	// Choose random radius vector. It will be normalized and then multiply by the average distance of the body from the origin to locate it at t=0. It is suppose to be a realistic initial condition for the position.
	double position_sun[3]={0,0,0};
	double position_jupiter[3]={1,0,0};
	double position_saturn[3]={0,1,0};

	// Choose random velocity vector. It will be normalized and then multiply by the average velocity of the body at t=0. It is suppose to make a realistic initial condition...
	double velocity_sun[3]={0,0,0};
	double velocity_jupiter[3]={0,1,0};
	double velocity_saturn[3]={-1,0,0};

	// The body's construcors arguments: (double input_mass, double input_av_dist, double x, double y, double z, double input_av_speed, double velocity_x, double velocity_y, double velocity_z)

	// The sun's constructor:
	body sun(norm_masses[0],av_distance_sun, position_sun[0], position_sun[1], position_sun[2], av_speed_sun, velocity_sun[0], velocity_sun[1], velocity_sun[2]);

	// Jupiter's constructor:
	body jupiter(norm_masses[1], av_distance_jupiter, position_jupiter[0], position_jupiter[1], position_jupiter[2], av_speed_jupiter, velocity_jupiter[0], velocity_jupiter[1], velocity_jupiter[2]);

	// Saturn's constructor:
	body saturn(norm_masses[2],av_distance_saturn, position_saturn[0], position_saturn[1], position_saturn[2], av_speed_saturn,velocity_saturn[0], velocity_saturn[1],velocity_saturn[2] );

	//We make a list of all the bodies
	body body_list[3]={sun, jupiter, saturn};

	//Now the initial conditions. We normalize the initial position and initial velocity vectors of each body. Then we multiply the normalized position vectors by the average distance of the body from the sun, and multiply the unit speed vector by the average velocity of the body around the sun.

	for(int i=0; i<3; i++)
	{
		// la boucle parcours la liste des body. La fonction vector_normalization agit d'elle même sur les composantes des vecteurs à normaliser.
		body_list[i].vector_normalization(&body_list[i].init_position_vector[0]);
		body_list[i].vector_normalization(&body_list[i].init_speed_vector[0]);

		//We must multiply each components of the initial unit position vectors by the average distance of the body. NB: les composantes du vecteur unité sont les cosinus directeur.
		for(int j=0; j<3; j++)
        {
			body_list[i].position[j]=(body_list[i].init_position_vector[j])*(body_list[i].init_distance);

        }
		//We must multiply each components of the initial unit velocity vector by the average speed of the body. NB: les composantes du vecteur unité sont les cosinus directeur. ET les moments sont normalisés à la masse du soleil.
		for(int j=0; j<3; j++)
        {
			body_list[i].moment[j]=(body_list[i].init_speed_vector[j])*(body_list[i].init_speed)*(body_list[i].norm_mass);
        }

		// Les deux boucles suivantes affichent à l'écran les valeurs initiales des vecteurs position et vitesse.
        for(int k = 0; k<3; k++)
        {
            cout << "position du corp " << i << ", x_" << k << " = " << body_list[i].position[k] << endl;
        }
        for(int k = 0; k<3; k++)
        {
            cout << "Moment du corp " << i << ", m_" << k << " = " << body_list[i].moment[k] << endl;
        }

	}
	int a;
	cout << "The size of int a is " << sizeof(a) << " bytes. Or " << sizeof(a)*8 << " bits."<< endl;

	for(int i= 1; i*dt<=5000; i++)
    {
		for(int l=0; l<3; l++)
		{
			for(int m=0; m<3; m++)
			{
				body_list[l].dx_ab
			}
		}
		F12_i_plus_1 = 
    }

	return 0;
}
