#include <iostream>
#include <string>
#include <sstream>
#include <math.h>
using namespace std;
#define PI 3.14159
#define NEWLINE '\n'

double f_distance(double *p1, int indice_1, int indice_2)
{
	double d=0;
	for(int i=0; i<3; i++)
	{
		double a=p1[indice_1];
		double b=p1[indice_2];
		d = d + ((a-b)*(a-b)); //le carré de la différence des composantes.
		indice_1++;
		indice_2++;

	}
	return sqrt(d);
}

int main()
{
	double G = 1; // A adapter.
    double period = 5000; // Temps en année.
	double dt = 1/(365*period);

	double M_sol = 1.989e30; //Masse du soleil en kg.
	double M_jup = 1.898e27;
	double M_sat = 5.683e26;

	double m_sol = 1; //On normalise toutes les masses à celle du soleil.
	double m_jup = M_jup/M_sol;
	double m_sat = M_sat/M_sol;

	//Ordre x,y,z soleil, jupiter, saturne.
	double position[9]={0,0,0,1,1,1,2,2,2};
	double moment[9]={};
	double force[9]={};
	double distance[3];//distance[0]=soleil-jupiter, distance[1]=soleil-saturne, distance[2]=jupiter-saturne

	double * p_distance;
	p_distance = &distance[0]; // pointeur du vecteur distance

	double * p_position;
	p_position = &position[0]; // pointeur du vecteur position


	for(int i=1; i*dt<=5000; i++)
	{
		for(int i = 0; i<3; i++)
		{
			// Ces deux indice servirons à définir la composante de départ du vecteur position (à 9 composantes car il contient les composantes x,y,z de tous les corps) pour calculer la distance entre deux corps.
			int indice_1;
			int indice_2;

			if (i==0)//Calcul distance soleil-jupiter
			{
				indice_1=0;
				indice_2=3;
			}
			else if (i==1)//calcul distance soleil-saturne
			{
				indice_1=0;
				indice_2=6;
			}
			else //calcul distance jupiter-saturne
			{
				indice_1=3;
				indice_2=6;
			}
			//distance[0]=soleil-jupiter, distance[1]=soleil-saturne, distance[2]=jupiter-saturne.
			//la fonction f_distance prend en argument deux pointeurs. Ils localisent la composante de départ du vecteur position (9 composantes) pour ensuite calculer la distance entre deux corp. La fonction parcourera les 2 composantes suivante d'elle même. La composante de départ étant la composante x et les deux suivantes sont y et z.
			if(i=!n)
			p_distance[i] = f_distance(p_position, indice_1, indice_2);
			cout << p_distance[i] << endl;
		}


		for(int i=0; i<9; i++)
		{

		}
	}


	
}
